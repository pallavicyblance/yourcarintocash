from flask import Flask ,request
import pymysql
import requests
import logging
from Misc.functions import *
from module.acceptedaps import Acceptedaps
from module.admin import Admin

acceptedaps = Acceptedaps()
admin = Admin()

class OutBid:

    def connect(self):
        return pymysql.connect(host="localhost", user="root", password="", database="carintocash", charset='utf8mb4') 
     
    def auction_out_bid():
        logging.info('-----cron job out bid started-----')
        print('-----cron job out bid started-----')
        active_auction = acceptedaps.getauctions()
        getjwttoken = admin.getjwttoken(acv_user()[0])
        for auction in active_auction:
            user_bid = bid_amount(request.form,auction[4],acv_user()[0])
            if auction[9] >= user_bid:
                place_auction_bid(auction[4],auction[25],getjwttoken[0])

        logging.info('-----cron job out bid ended-----')
        print('-----cron job out bid ended-----')
        return 'success'
    
def bid_amount(self,auctionId, userId):
    con = OutBid.connect(self)
    cursor = con.cursor()
    try:
        cursor.execute("SELECT * FROM bids WHERE auction_id = %s AND user_id = %s", (auctionId, userId))
        bid = cursor.fetchone()
        return bid[2]
    except:
        return 0
    
def place_auction_bid(auctionId, bidamount, jwttoken):

    url = f'https://buy-api.gateway.staging.acvauctions.com/v2/auction/{auctionId}/bid'
    json_data  = {'amount': bidamount}
    headers = {'Authorization': jwttoken,'Content-Type': 'application/json'}
    
    try:
        response = requests.post(url, json=json_data ,headers=headers)
        response.raise_for_status()  
        if response.status_code == 200:
            acceptedaps.addbid(auctionId,bidamount,acv_user()[0])
            acceptedaps.place_bid(auctionId, bidamount)
            logging.info("auction %s: placed bid with amount %s", auctionId, bidamount)
            print('auction ' + str(auctionId) + ' placed bid with amount ' + str(bidamount))
            return 'status'
        
    except requests.exceptions.RequestException as e:
        logging.info("Response for auction %s: %s", auctionId, response.text)
        print("Response for auction :" + str(auctionId), response.text)
        return None 