$(function () {
    "use strict";

	
	//Line Chart

	new Chart(document.getElementById("line-chart"), {
	  type: 'line',
	  data: {
		labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
		datasets: [{ 
			data: [800, 900, 1000, 1100, 1200, 1300, 1400, 1600, 1800, 2000, 2100 , 2200],
			label: "Completed",
			borderColor: "#3e95cd",
			backgroundColor: "#3e95cd",
			fill: false
		  }, { 
			data: [500, 600, 700, 800, 900, 1060, 1100, 1200, 1300, 1400, 1600, 1800],
			label: "Incomplete",
			borderColor: "#ffcd56",
			backgroundColor: "#ffcd56",
			fill: false
		  }, { 
			data: [250, 400, 600, 800, 1000, 1300, 1600, 1700, 1800, 1900, 2000, 2100],
			label: "Accepted",
			borderColor: "#22b573",
			backgroundColor: "#22b573",
			fill: false
		  }, { 
			data: [100, 200, 400, 600, 800, 1000, 1200, 1300, 1400, 1500, 1600, 2000],
			label: "Declined",
			borderColor: "#e40503",
			backgroundColor: "#e40503",
			fill: false
		  }
		]
	  },
	  options: {
		title: {
		  display: false,
		}
	  }
	});

	// line second
	

	

}); 