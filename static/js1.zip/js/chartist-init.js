$(function () {
    "use strict";
//Simple line chart 

new Chartist.Line('.ct-sm-line-chart', {
		 labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
		 series: [
			[50, 45, 30, 73, 50, 100, 37, 47, 80, 17, 16, 18],
			[75, 54, 73, 57, 35, 80, 20, 49, 28, 20, 55, 33],
			[15, 14, 13, 57, 25, 10, 30, 42, 88, 20, 66, 98],
			[15, 14, 13, 77, 85, 10, 38, 49, 48, 70, 46, 28],
  		]
	}, {
	fullWidth: true,
	plugins: [
		Chartist.plugins.tooltip()
	  ],
	chartPadding: {
		right: 60
	}
});





// Bar chart

var data = {
  labels: ['Facebook', 'Twitter', 'Linkdin'],
  series: [
    [20, 50, 100,]
  ]
};

var options = {
  seriesBarDistance: 10
};

var responsiveOptions = [
  ['screen and (max-width: 640px)', {
    seriesBarDistance: 5,

    axisX: {
      labelInterpolationFnc: function (value) {
        return value[0];
      }
    }
  }]
];

new Chartist.Bar('.ct-bar-chart', data, options, responsiveOptions);



});