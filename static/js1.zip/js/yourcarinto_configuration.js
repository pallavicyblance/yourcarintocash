
const body_damage = {'AO': 'All Over', 'BN': 'Burn', 'FR': 'Front End', 'MN' : 'Minor dent/Scratches', 'RO' : 'Rollover', 'RE' : 'Rear End', 'SD' : 'Side Damage', 'TP' : 'Top/Roof' };
