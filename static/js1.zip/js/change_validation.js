$(function(){
	$('#changepassword_button').click(function(){
		var oldpassword = $("#old_password"); //done
		var newpassword = $("#new_password"); //done
		var confirmpassword = $("#confirm_password"); //done


		var oldpassword_span = $("#old_password_span");
		var newpassword_span = $("#new_password_span");
		var confirmpassword_span = $("#confirm_password_span");

		oldpassword.blur(validate_oldpassword);
		newpassword.blur(validate_newpassword);
		confirmpassword.blur(validate_confirmpassword);

		oldpassword.keyup(validate_oldpassword);
		newpassword.keyup(validate_newpassword);
		confirmpassword.keyup(validate_confirmpassword);
		// darshan changes 31-08-2023 1
		if(validate_oldpassword() & validate_newpassword() & validate_confirmpassword()){
			$.ajax({
				url: WS_PATH+'addusertyps',
				data: $('#updatepass').serialize(),
				type: 'POST',
				success: function(response){
					$('#inquiry_msg').show();
					$( "#inquiry_msg" ).html(response);

				   	setTimeout(function(){ window.location.reload(); }, 2000);

				},
				error: function(error){
					console.log(error);
				}
			});
		}
		// darshan changes 31-08-2023 1 close
		function validate_oldpassword(){
			if($("#old_password").val() == ''){
				oldpassword_span.text("This field is required.");
				oldpassword_span.addClass("message_error");
				return false;
			}else{
			  if($("#old_password").val() == $("#old_password_fetch").val()){
			  	oldpassword_span.text("");
				oldpassword_span.removeClass("message_error");
				return true;
			  }else{
			  	oldpassword_span.text("Old Password does not match.");
				oldpassword_span.addClass("message_error");
				return false;
			  }

			}
		}
		// darshan changes bug shhet 4-09-2023 1
		function validate_newpassword(){
			var passwordInput = $("#new_password").val();
			if($("#new_password").val() == ''){
				newpassword_span.text("This field is required.");
				newpassword_span.addClass("message_error");
				return false;
			}else if (passwordInput.length < 8) {
				newpassword_span.text("The password must be at least 8 characters.The password format is invalid.");
				newpassword_span.addClass("error");
				return false;
			} else {
				var strongRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
				if (strongRegex.test(passwordInput)) {
					newpassword_span.text("");
					newpassword_span.removeClass("error");
					return true;
				} else {
					newpassword_span.text("The password must be at least 8 characters.The password format is invalid.");
					newpassword_span.addClass("error");
					return false;
				}
			}
		}

		function validate_confirmpassword(){
			if($("#confirm_password").val() == ''){
				confirmpassword_span.text("This field is required.");
				confirmpassword_span.addClass("message_error2");
				return false;
			}else{
				if($("#new_password").val() == $("#confirm_password").val()){
					confirmpassword_span.text("");
					confirmpassword_span.removeClass("message_error");
					return true;
				}else{
					confirmpassword_span.text("Password does not match.");
					confirmpassword_span.addClass("message_error");
					return false;
				}
			}
		}
		// darshan changes bug shhet 4-09-2023 1 close
	});
});




