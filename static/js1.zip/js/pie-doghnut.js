$(function() {
    "use strict";
    // ------------------------------
    // Basic pie chart
    // ------------------------------
    // based on prepared DOM, initialize echarts instance
        var basicpieChart = echarts.init(document.getElementById('basic-pie'));
        var option = {
            // Add title
                title: {
                    text: '',
                    subtext: '',
                    x: 'center'
                },

                // Add tooltip
                tooltip: {
                    trigger: 'axis',
                    formatter: "{a} <br/>{b}: {c} ({d}%)"
                },
				

                // Add legend
                legend: {
                    orient: 'vertical',
                    x: 'left',
					data: ["USA", "Canada", "Australia", "UK", "Norway"],
                },

                // Add custom colors
                color: ["#03a9f4", "#e861ff","#08ccce","#e2b35b","#e40503"],

                // Display toolbox
                toolbox: {
                    show: true,
                    orient: 'vertical',
                    feature: {
                        mark: {
                            show: true,
                            title: {
                                mark: 'Markline switch',
                                markUndo: 'Undo markline',
                                markClear: 'Clear markline'
                            }
                        },
                        magicType: {
                            show: true,
                            title: {
                                pie: 'Switch to pies',
                                funnel: 'Switch to funnel',
                            },
                            type: ['pie', 'funnel'],
                            option: {
                                funnel: {
                                    x: '25%',
                                    y: '20%',
                                    width: '50%',
                                    height: '70%',
                                    funnelAlign: 'left',
                                    max: 1548
                                }
                            }
                        }
                    }
                },

                // Enable drag recalculate
                calculable: true,
                // Add series
                series: [{
                    name: 'Country',
                    type: 'pie',
                    radius: '70%',
                    center: ['50%', '57.5%'],
                    data: [
                        {value: 50, name: 'USA'},
                        {value: 170, name: 'Canada'},
                        {value: 234, name: 'Australia'},
						{value: 200, name: 'UK'},
						{value: 100, name: 'Norway'}
                    ]
                }],
				animationDuration: 10000
        };
    
        basicpieChart.setOption(option);
 
});